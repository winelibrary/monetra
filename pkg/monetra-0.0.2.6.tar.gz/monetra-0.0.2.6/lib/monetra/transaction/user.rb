module Monetra
	module Transaction
		module User
			class Request
				attr_accessor :username, :password, :action, :account
			end
			
			class Response
				
			end
		end
	end
end