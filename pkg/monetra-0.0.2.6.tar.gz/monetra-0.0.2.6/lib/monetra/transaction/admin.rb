module Monetra
	module Transaction
		class Admin
			
		end
	end
end