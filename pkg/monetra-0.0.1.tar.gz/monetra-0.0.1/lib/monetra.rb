require 'net/http'
require 'open-uri'
require 'builder'

module Monetra
	
end