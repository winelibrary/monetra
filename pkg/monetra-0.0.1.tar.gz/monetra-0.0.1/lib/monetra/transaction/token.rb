module Monetra
	module Transaction
		module Token
			class Request
				attr_accessor :username, :password, :action, :account, :admin, :type, :expdate, :street, :zip, :clientref, :desc, :token, :expdate_end
				attr_accessor :active, :hist_id, :amount, :installment_total, :frequency, :bdate, :edate, :cardholdername
				def initialize(attributes={})
					attributes.each do |att, val|
						self.__send__("#{att}=", val) if self.respond_to?("#{att}=")
					end
				end
			end
			
			class Response
				attr_accessor :code, :verbiage, :token
				attr_accessor :token, :type, :active, :cardtype, :account, :expdate, :cardholdername, :street, :zip, :descr, :clientref, :amount, :frequency, :bdate, :edate, :installment_num, :installment_total
				attr_accessor :last_run_id, :last_success_date, :last_run_date, :next_run_date, :next_run_amount, :abaroute, :datablock
				
				def initialize(attributes={})
					attributes.each do |att, val|
						self.__send__("#{att}=", val) if self.respond_to?("#{att}=")
					end
				end
				
				def datablock=(data)
					puts data.inspect
					csv_data = CSV.parse(data)
					headers = csv_data.shift.map {|i| i.to_s }
					string_data = csv_data.map {|row| row.map {|cell| cell.to_s } }
					array_of_hashes = string_data.map {|row| Hash[*headers.zip(row).flatten] }
					array_of_hashes.first.each_pair do |k,v|
						self.__send__("#{k}=", v)
					end
				end
				
				
			end
			
			
			def self.new(attributes={})
				request = Request.new(attributes)
#				raise Monetra::Parse.request(request).inspect
				body = Connection.post(Monetra::Parse.request(request))
				puts body.inspect
				body = Hash.from_xml(body)
				transfer_status = body["MonetraResp"]["DataTransferStatus"]
				responses = case body["MonetraResp"]["Resp"].class.to_s
				when "Hash"
					response_hash = {}
					body["MonetraResp"]["Resp"].each_pair do |k,v|
						response_hash[k.downcase] = v
					end
					puts response_hash.inspect
					[Response.new(response_hash)]
				when "Array"
					body["MonetraResp"]["Resp"].map do |resp|
						response_hash = {}
						resp.each_pair do |k,v|
							response_hash[k.downcase] = v
						end
						puts response_hash.inspect
						Response.new(resp)
					end
				end
				responses
			end
		end
	end
end
